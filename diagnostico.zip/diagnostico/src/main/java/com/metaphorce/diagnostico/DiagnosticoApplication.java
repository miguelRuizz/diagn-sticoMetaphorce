package com.metaphorce.diagnostico;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DiagnosticoApplication {

	public static void main(String[] args) {
		SpringApplication.run(DiagnosticoApplication.class, args);
	}

}
